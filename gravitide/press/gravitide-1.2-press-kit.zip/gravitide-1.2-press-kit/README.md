# Gravitide press kit

Turn space debris into a weapon in a one-finger physics arcade game for iPhone.

**Version 1.2 — available on the App Store.** Released 12 November 2026.

[App Store](https://apps.apple.com/us/app/gravitide-gravity-throw/id6809525146) · [Developer](https://x.com/kostyabl) · [Plain-text press kit](press-kit.txt)

## About the game

Gravitide is a one-finger physics arcade game for iPhone. Hold the screen to draw your ship and nearby debris into orbit, charge a fragment, then release it as a projectile. The same gravity that helps you attack also moves your ship, so every throw is a balance of aim, timing and survival. The campaign spans 15 expeditions, five sectors and 55 waves, with upgrades, unlockable modules and boss encounters. Version 1.2 adds a hands-on flight lesson, clearer aiming feedback, slower action when a throw is ready, and Spanish and German alongside English and Russian. The first three expeditions are free; one purchase unlocks the remaining twelve.

## Facts

| | |
|---|---|
| Developer | Kostya Blokhin |
| Platform | iPhone · iOS 18.6+ |
| Genre | Physics action arcade |
| Controls | One finger · portrait |
| Languages | English, Russian, Spanish, German |
| Campaign | 15 expeditions · 5 sectors · 55 waves |
| Free portion | First 3 expeditions |
| Full campaign | One non-consumable in-app purchase unlocks the other 12 |
| Ads / subscriptions | None |
| Offline | Gameplay works offline; downloading and acquiring/restoring purchases require a connection |

## New in version 1.2

- A hands-on lesson for steering the ship, throwing debris and avoiding damage.
- Clearer aiming feedback and slower action when a throw is ready.
- A calmer opening to the first expedition.
- Spanish and German localization alongside English and Russian.

## Downloadable assets

[Original app icon](assets/brand/gravitide-icon-1024.png) · [English short clip](assets/social/gravitide-throw-en.mp4) · [Short clip poster](assets/social/gravitide-throw-en-poster.jpg)

| Language | Screenshots | 26.5-second App Preview | Text |
|---|---|---|---|
| English | [en-US screenshots](assets/en-US/screenshots/) | [Preview](assets/en-US/preview.mp4) | [Store copy](assets/en-US/store-copy.txt) |
| Russian | [ru screenshots](assets/ru/screenshots/) | [Preview](assets/ru/preview.mp4) | [Store copy](assets/ru/store-copy.txt) |
| Spanish | [es-ES screenshots](assets/es-ES/screenshots/) | [Preview](assets/es-ES/preview.mp4) | [Store copy](assets/es-ES/store-copy.txt) |
| German | [de-DE screenshots](assets/de-DE/screenshots/) | [Preview](assets/de-DE/preview.mp4) | [Store copy](assets/de-DE/store-copy.txt) |

Screenshots are original 1320 × 2868 PNG files. App Previews are original 886 × 1920 MP4 files. The short clip is 1080 × 1920, 30 fps, 10.5 seconds; it shows two tutorial throws at their original speed followed by an end card. Videos are silent; no music has been added.

The full previews and screenshot galleries include later expeditions from the paid portion of the campaign. The social throw clip shows the tutorial. The first three expeditions are free.

Credit: **Kostya Blokhin / Gravitide**. Assets supplied for editorial coverage and reviews of Gravitide.
